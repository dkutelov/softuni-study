const router = require("express").Router();

router.get("/", (req, res) => {
  res.redirect("/expenses");
});

module.exports = router;
